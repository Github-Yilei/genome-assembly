#include <stdio.h>
char * storeNexusFile (FILE *);
